# -*- coding: utf-8 -*-
import pandas as pd
from datetime import date
import datetime
import numpy as np
from time import sleep
import zipfile
import openpyxl
from selenium import webdriver
import wget
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from os import remove

# browser = webdriver.Chrome()
# browser.get("https://www.gob.mx/salud/documentos/datos-abiertos-152127?fbclid=IwAR09jQZhrypAG9WqdU1B_D6FDHjAkxLa9CvC1UMbzT59e0wnStZOMI8hsIk")
# content = browser.find_elements_by_css_selector('td a')
# datos_coronavirus = content[0].get_attribute('href')
# dict_coronavirus = content[1].get_attribute('href')

dict_coronavirus = 'http://187.191.75.115/gobmx/salud/datos_abiertos/diccionario_datos_covid19.zip'
datos_coronavirus = 'http://187.191.75.115/gobmx/salud/datos_abiertos/datos_abiertos_covid19.zip'
wget.download(dict_coronavirus)
ultimo = dict_coronavirus.rfind('/')
dict_coronavirus =dict_coronavirus[ultimo+1:]
wget.download(datos_coronavirus)
ultimo = datos_coronavirus.rfind('/')
datos_coronavirus = datos_coronavirus[ultimo+1:]

with zipfile.ZipFile(dict_coronavirus, 'r') as zip_ref:
    arch_dict = zip_ref.namelist()
    print(zip_ref.namelist())
    zip_ref.extractall('./')

with zipfile.ZipFile(datos_coronavirus, 'r') as zip_ref:
    arch_datos = zip_ref.namelist()
    print(zip_ref.namelist())
    zip_ref.extractall('./')

datos_df = pd.read_csv(arch_datos[0])

#busca archivo de Catalogos
for iarchivos in arch_dict:
    if 'Catalogos' in iarchivos:
        archivo_catalogos = iarchivos

excel_data = openpyxl.load_workbook(archivo_catalogos)
exelKey = excel_data.sheetnames

# lista_Columna = [
# 1 => 'Catálogo ORIGEN' => ['ORIGEN'],
# 2 => 'Catálogo SECTOR' =>['SECTOR'],
# 3 => 'Catálogo SEXO' => ['SEXO'],
# 4 => 'Catálogo TIPO_PACIENTE'=> ['TIPO_PACIENTE'],
# 5 => 'Catálogo SI_NO'=> ['INTUBADO', 'NEUMONIA', 'EMBARAZO', 'HABLA_LENGUA_INDI', 'DIABETES', 'EPOC', 'ASMA', 'INMUSUPR', 'HIPERTENSION', 'OTRA_CON', 'CARDIOVASCULAR', 'OBESIDAD', 'RENAL_CRONICA', 'TABAQUISMO','OTRO_CASO','MIGRANTE', 'UCI'],
# 6 => 'Catálogo NACIONALIDAD'=> ['NACIONALIDAD','PAIS_NACIONALIDAD', 'PAIS_ORIGEN'],
# 7 => 'Catálogo RESULTADO'=> ['RESULTADO'],
# 8 => 'Catálogo de ENTIDADES'=> ['ENTIDAD_UM','ENTIDAD_NAC', 'ENTIDAD_RES'],
# 9 => 'Catálogo MUNICIPIOS' => ['MUNICIPIO_RES']]

entidades = pd.read_excel(archivo_catalogos, sheet_name=exelKey[7],index='CLAVE_ENTIDAD')


datos_entidades =  pd.DataFrame()
for icol in range(1,4):
    datos_filtro = datos_df[datos_df['RESULTADO']==icol]
    datos_enfermos = datos_filtro.groupby(['ENTIDAD_UM'])['RESULTADO'].count()
    datos_entidades=pd.concat([datos_entidades, datos_enfermos], axis=1)

datos_filtro = datos_df[datos_df['FECHA_DEF']!='9999-99-99']
datos_filtro = datos_filtro[datos_filtro['RESULTADO']==1]
datos_enfermos = datos_filtro.groupby(['ENTIDAD_UM'])['FECHA_DEF'].count()
datos_entidades=pd.concat([datos_entidades, datos_enfermos], axis=1)

#CAMBIA NOMBRE A FILAS Y COLUMNAS
datos_entidades.columns = ['Positivo','Negativo','Sospechoso', 'Defunciones']
for ind in datos_entidades.index:
    nombreEnidad = entidades[entidades['CLAVE_ENTIDAD']==ind]['ENTIDAD_FEDERATIVA'].tolist()
    datos_entidades.rename(index={ind:nombreEnidad[0]}, inplace=True)

print(datos_entidades)
today = date.today()
datos_entidades.to_csv('tablaCoranovirus' + arch_datos[0])

remove(dict_coronavirus)
remove(datos_coronavirus)
for iarc in arch_dict:
    remove(iarc)
# for idk in range(len(exelKey)):
#     iKeydict = exelKey[idk]
#     dato1 = pd.read_excel(archivo_catalogos, sheet_name=exelKey[9])
#     headict = dato1.keys()
#     print(dato1)
#     for ikeyData in datos_df.keys():
#         if ikeyData in lista_Columna[idk]:
#             print(lista_Columna[idk])
#             for ind in dato1.index:
#                 datos_df[ikeyData][datos_df[ikeyData] == dato1[headict[0]][ind]] = dato1[headict[1]][ind]
#                 print(dato1[headict[0]][ind],dato1[headict[1]][ind])
#
