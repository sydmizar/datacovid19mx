cd /run/media/fabian/2FAAED6427E1BCD3/Documentos/Mesura/Coronavirus/abiertos
python get_data_mx_carto.py > salida.out
